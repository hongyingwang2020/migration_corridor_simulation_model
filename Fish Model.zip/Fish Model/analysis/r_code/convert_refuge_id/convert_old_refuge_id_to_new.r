setwd("E:/HexSim_Models/R_code/convert_refuge_id/")
#### import in conversion table ####
refuge_id_old_new <- read.csv("E:/HexSim_Models/R_code/convert_refuge_id/refuge_id_old_new.csv")


#### catch and keep refuge id conversion ####
Catch.and.Keep <- read.csv("E:/HexSim_Models/R_code/convert_refuge_id/Catch and Keep.csv")
# merge
Catch.and.Keep2<-merge(refuge_id_old_new, Catch.and.Keep,  by.y="Refuge.ID", by.x="old_id", all.x=TRUE)
# sort by new ID
Catch.and.Keep3<-Catch.and.Keep2[order(Catch.and.Keep2$new_id),]
# drop unnecessary columns
for_keep<-c(3,4)
Catch.and.Keep4<-Catch.and.Keep3[, for_keep]
# export
write.csv(Catch.and.Keep4, "Catch and Keep2.csv")

#### catch and release refuge id conversion ####
Catch.and.Release <- read.csv("E:/HexSim_Models/R_code/convert_refuge_id/Catch and Release.csv")
# merge
Catch.and.Release2<-merge(refuge_id_old_new, Catch.and.Release,  by.y="Refuge.ID", by.x="old_id", all.x=TRUE)
# sort by new ID
Catch.and.Release3<-Catch.and.Release2[order(Catch.and.Release2$new_id),]
# drop unnecessary columns
for_Release<-c(3,4)
Catch.and.Release4<-Catch.and.Release3[, for_Release]
# export
write.csv(Catch.and.Release4, "Catch and Release2.csv")

#### refuge volume refuge id conversion ####
volumes <- read.csv("E:/HexSim_Models/R_code/convert_refuge_id/Refuge Volumes.csv")
# merge
volumes2<-merge(refuge_id_old_new, volumes,  by.y="�..num_id", by.x="old_id", all.x=TRUE)
# sort by new ID
volumes3<-volumes2[order(volumes2$new_id),]
# drop unnecessary columns
for_keep<-c(3,4)
volumes4<-volumes3[, for_keep]
# export
write.csv(volumes4, "Refuge Volumes2.csv")

#### water temperature refuge id conversion ####
temperature <- read.csv("E:/HexSim_Models/R_code/convert_refuge_id/River Temperature.csv")
# merge
temperature2<-merge(refuge_id_old_new, temperature,  by.y="num_id", by.x="old_id", all.x=TRUE)
# sort by new ID
temperature3<-temperature2[order(temperature2$new_id),]
# drop unnecessary columns
temperature4<-temperature3[, 4:2949]
# export
write.csv(temperature4, "River Temperature2.csv")



